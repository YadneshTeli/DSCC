package prac9;

import java.util.concurrent.*;
import java.util.*;
import java.util.stream.Collectors;

public class RingElectionEclipse {
	
    // Message types used in the protocol
    enum MsgType { ELECTION, COORDINATOR }

    static class Message {
        final MsgType type;
        final int id; // carries candidate id or coordinator id

        Message(MsgType type, int id) {
            this.type = type;
            this.id = id;
        }

        @Override
        public String toString() {
            return type + "(" + id + ")";
        }
    }

    // Each process is a Runnable with its own input queue
    static class ProcessNode implements Runnable {
        final int id;
        final BlockingQueue<Message> inbox;
        List<ProcessNode> ring; // reference to ring to find next alive
        volatile Integer coordinator = null;
        volatile boolean alive;
        volatile boolean electionInProgress = false;

        ProcessNode(int id, boolean alive, List<ProcessNode> ring) {
            this.id = id;
            this.inbox = new LinkedBlockingQueue<>();
            this.alive = alive;
            this.ring = ring;
        }

        // helper: find next alive node index clockwise
        private ProcessNode findNextAlive() {
            int n = ring.size();
            int idx = (id % n); // since ids are 1..N, map to 0..n-1 by id % n
            // start from next process
            for (int step = 1; step < n; step++) {
                int candidateIndex = (idx + step) % n;
                ProcessNode p = ring.get(candidateIndex);
                if (p.alive) return p;
            }
            return null; // no other alive node
        }

        // send message to next alive node
        private void sendToNext(Message m) {
            ProcessNode next = findNextAlive();
            if (next == null) {
                System.out.printf("P%d: No other alive nodes to send %s%n", id, m);
                return;
            }
            System.out.printf("P%d -> P%d : %s%n", id, next.id, m);
            try {
                next.inbox.put(m);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        // initiate election from this process
        void initiateElection() {
            if (!alive) {
                System.out.printf("P%d is down and cannot initiate election.%n", id);
                return;
            }
            System.out.printf("P%d: Initiating election with ELECTION(%d)%n", id, id);
            electionInProgress = true;
            sendToNext(new Message(MsgType.ELECTION, id));
        }

        @Override
        public void run() {
            try {
                while (true) {
                    Message m = inbox.take(); // blocks until message arrives
                    if (!alive) {
                        // If we are down we ignore incoming messages (simulate crash)
                        System.out.printf("P%d (DOWN): ignoring message %s%n", id, m);
                        continue;
                    }

                    switch (m.type) {
                        case ELECTION:
                            handleElectionMessage(m.id);
                            break;
                        case COORDINATOR:
                            handleCoordinatorMessage(m.id);
                            break;
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.printf("P%d: terminating thread.%n", id);
            }
        }

        private void handleElectionMessage(int candidateId) {
            System.out.printf("P%d: received ELECTION(%d)%n", id, candidateId);
            if (candidateId == this.id) {
                // message returned to originator -> I am coordinator
                System.out.printf("P%d: my id returned -> I am COORDINATOR%n", id);
                this.coordinator = id;
                // announce coordinator around the ring
                sendToNext(new Message(MsgType.COORDINATOR, id));
            } else if (candidateId > this.id) {
                // forward candidate unchanged
                System.out.printf("P%d: forwarding ELECTION(%d)%n", id, candidateId);
                sendToNext(new Message(MsgType.ELECTION, candidateId));
            } else {
                // candidateId < this.id
                System.out.printf("P%d: replacing candidate %d with my id %d and forwarding%n",
                        id, candidateId, id);
                sendToNext(new Message(MsgType.ELECTION, this.id));
            }
        }

        private void handleCoordinatorMessage(int coordId) {
            System.out.printf("P%d: received COORDINATOR(%d) -> setting coordinator%n", id, coordId);
            this.coordinator = coordId;
            // if coordinator message hasn't completed a full circle, forward
            if (coordId != this.id) {
                sendToNext(new Message(MsgType.COORDINATOR, coordId));
            } else {
                // coordinator message returned to coordinator: election finished
                System.out.printf("P%d: coordinator announcement completed around ring.%n", id);
            }
        }
    }

    // Utility to build ring with processes numbered 1..N in list index order
    private static List<ProcessNode> buildRing(int N, Set<Integer> aliveSet) {
        List<ProcessNode> ring = new ArrayList<>(Collections.nCopies(N, null));
        // Create placeholder nodes first so references are consistent
        for (int i = 1; i <= N; i++) {
            ring.set(i - 1, new ProcessNode(i, aliveSet.contains(i), null));
        }
        // set ring reference for each node
        for (int i = 0; i < N; i++) {
            ring.get(i).ring = ring;
        }
        return ring;
    }

    public static void main(String[] args) throws Exception {
    	
        Scanner sc = new Scanner(System.in);
        System.out.println("Ring Election Algorithm Simulation (Chang–Roberts) — Single JVM");

        System.out.print("Enter number of processes N [default 6]: ");
        String nLine = sc.nextLine().trim();
        int N = nLine.isEmpty() ? 6 : Integer.parseInt(nLine);

        System.out.print("Enter alive process IDs (comma-separated) [default all alive]: ");
        String aliveLine = sc.nextLine().trim();
        Set<Integer> aliveSet;
        if (aliveLine.isEmpty()) {
            aliveSet = new HashSet<>();
            for (int i = 1; i <= N; i++) aliveSet.add(i);
        } else {
            aliveSet = Arrays.stream(aliveLine.split(","))
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .map(Integer::parseInt)
                    .collect(Collectors.toSet());
        }

        System.out.print("Enter initiator process id (must be alive) [default 1]: ");
        String initLine = sc.nextLine().trim();
        int initiator = initLine.isEmpty() ? 1 : Integer.parseInt(initLine);
        if (!aliveSet.contains(initiator)) {
            System.out.printf("Initiator %d is not alive. Changing initiator to smallest alive: %d%n",
                    initiator, Collections.min(aliveSet));
            initiator = Collections.min(aliveSet);
        }

        // build ring
        List<ProcessNode> ring = new ArrayList<>();
        for (int i = 1; i <= N; i++) {
            boolean isAlive = aliveSet.contains(i);
            ring.add(new ProcessNode(i, isAlive, null));
        }

        // now assign ring reference
        for (ProcessNode p : ring) p.ring = ring;

        // start threads for all nodes (alive or down; down nodes just ignore)
        ExecutorService exec = Executors.newFixedThreadPool(N);
        for (ProcessNode p : ring) {
            exec.submit(p);
            System.out.printf("P%d: %s%n", p.id, p.alive ? "ALIVE" : "DOWN");
        }

        // short sleep to let threads start
        Thread.sleep(500);

        // start election from initiator
        System.out.printf("%n--- Initiator P%d starting election --- %n%n", initiator);
        ProcessNode starter = ring.get(initiator - 1);
        starter.initiateElection();

        // Wait for election to conclude: poll until all alive nodes have coordinator set
        int waitSecs = 20;
        long deadline = System.currentTimeMillis() + waitSecs * 1000L;
        while (System.currentTimeMillis() < deadline) {
            boolean allSet = true;
            Integer coord = null;
            for (ProcessNode p : ring) {
                if (!p.alive) continue;
                if (p.coordinator == null) {
                    allSet = false;
                    break;
                }
                if (coord == null) coord = p.coordinator;
                else if (!coord.equals(p.coordinator)) {
                    allSet = false;
                    break;
                }
            }
            if (allSet && coord != null) {
                System.out.printf("%nElection completed. Coordinator is P%d%n", coord);
                break;
            }
            Thread.sleep(300);
        }

        System.out.println("\nShutting down simulation...");
        exec.shutdownNow();
        sc.close();
    }
}
