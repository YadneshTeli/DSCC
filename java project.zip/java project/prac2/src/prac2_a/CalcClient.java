package prac2_a;

import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class CalcClient {
    public static final int PORT = 9901;
    public static void main(String[] args) throws Exception {
         
        try(DatagramSocket sock = new DatagramSocket(); Scanner sc=new Scanner(System.in)) {
            System.out.print("Enter request (e.g. ADD 5 3): ");
            String req = sc.nextLine().trim();
            byte[] b = req.getBytes(StandardCharsets.UTF_8);
            InetAddress localhost = InetAddress.getByName("localhost");
            sock.send(new DatagramPacket(b, b.length, localhost, PORT));
            byte[] buf = new byte[256];
            DatagramPacket p = new DatagramPacket(buf, buf.length);
            sock.receive(p);
            System.out.println("Server says: " + new String(p.getData(),0,p.getLength(),StandardCharsets.UTF_8));
        }
    }
}
