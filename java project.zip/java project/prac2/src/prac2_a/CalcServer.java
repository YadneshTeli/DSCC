package prac2_a;

import java.net.*;
import java.nio.charset.StandardCharsets;

public class CalcServer {
    public static final int PORT = 9901;

    public static void main(String[] args) throws Exception {
         
        DatagramSocket sock = new DatagramSocket(PORT);
        byte[] buf = new byte[256];
        System.out.println("CalcServer listening on " + PORT);

        while (true) {
            DatagramPacket p = new DatagramPacket(buf, buf.length);
            sock.receive(p);
            String req = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8).trim();
            System.out.println("Received request: " + req);

            String out;
            try {
                String[] parts = req.split("\\s+");
                if (parts.length < 3) {
                    out = "ERR: Format → <OP> <num1> <num2>";
                } else {
                    double a = Double.parseDouble(parts[1]);
                    double b = Double.parseDouble(parts[2]);
                    double r;
                    switch (parts[0].toUpperCase()) {
                        case "ADD": r = a + b; out = "Result = " + r; break;
                        case "SUB": r = a - b; out = "Result = " + r; break;
                        case "MUL": r = a * b; out = "Result = " + r; break;
                        case "DIV":
                            if (b == 0) out = "ERR: Divide by zero";
                            else out = "Result = " + (a / b);
                            break;
                        default: out = "ERR: Unknown operation";
                    }
                }
            } catch (Exception e) {
                out = "ERR: Bad format";
            }

            byte[] resp = out.getBytes(StandardCharsets.UTF_8);
            DatagramPacket respPacket = new DatagramPacket(resp, resp.length, p.getAddress(), p.getPort());
            sock.send(respPacket);
        }
    }
}
