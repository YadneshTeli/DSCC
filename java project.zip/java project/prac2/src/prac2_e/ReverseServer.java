package prac2_e;

import java.net.*;
import java.nio.charset.StandardCharsets;

public class ReverseServer {
    public static final int PORT = 9904;

    public static void main(String[] args) throws Exception {
         
        DatagramSocket socket = new DatagramSocket(PORT);
        byte[] buf = new byte[256];
        System.out.println("ReverseServer listening on port " + PORT);

        while (true) {
            DatagramPacket packet = new DatagramPacket(buf, buf.length);
            socket.receive(packet);

            String str = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8).trim();
            System.out.println("Received: " + str);

            String reversed = new StringBuilder(str).reverse().toString();
            String reply = "Reversed: " + reversed;

            byte[] resp = reply.getBytes(StandardCharsets.UTF_8);
            DatagramPacket response = new DatagramPacket(resp, resp.length, packet.getAddress(), packet.getPort());
            socket.send(response);
        }
    }
}
