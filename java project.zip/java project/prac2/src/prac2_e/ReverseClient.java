package prac2_e;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class ReverseClient {
    public static final int SERVER_PORT = 9904;

    public static void main(String[] args) throws Exception {
         
        Scanner sc = new Scanner(System.in);
        DatagramSocket socket = new DatagramSocket();

        System.out.print("Enter a string: ");
        String input = sc.nextLine();

        byte[] sendData = input.getBytes(StandardCharsets.UTF_8);
        InetAddress serverAddr = InetAddress.getByName("localhost");
        DatagramPacket packet = new DatagramPacket(sendData, sendData.length, serverAddr, SERVER_PORT);
        socket.send(packet);

        byte[] buf = new byte[256];
        DatagramPacket response = new DatagramPacket(buf, buf.length);
        socket.receive(response);

        String reply = new String(response.getData(), 0, response.getLength(), StandardCharsets.UTF_8);
        System.out.println("Server says: " + reply);

        // Extract reversed string for palindrome check
        String reversed = reply.replace("Reversed: ", "").trim();

        if (input.equalsIgnoreCase(reversed))
            System.out.println("The string is a palindrome!");
        else
            System.out.println("The string is not a palindrome!");

        socket.close();
        sc.close();
    }
}
