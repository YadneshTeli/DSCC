package prac2_c;

import java.net.*;
import java.nio.charset.StandardCharsets;

public class TimeAddServer {
    public static final int PORT = 9902;

    public static void main(String[] args) throws Exception {
         
        DatagramSocket socket = new DatagramSocket(PORT);
        byte[] buf = new byte[256];
        System.out.println("TimeAddServer listening on port " + PORT);

        while (true) {
            DatagramPacket packet = new DatagramPacket(buf, buf.length);
            socket.receive(packet);

            String req = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8).trim();
            System.out.println("Received: " + req);

            try {
                // Expected format: h1 m1 h2 m2
                String[] parts = req.split("\\s+");
                int h1 = Integer.parseInt(parts[0]);
                int m1 = Integer.parseInt(parts[1]);
                int h2 = Integer.parseInt(parts[2]);
                int m2 = Integer.parseInt(parts[3]);

                int totalMin = (h1 + h2) * 60 + (m1 + m2);
                int finalH = totalMin / 60;
                int finalM = totalMin % 60;

                String res = String.format("%02d:%02d Hours , %d Minutes", finalH, finalM, totalMin);

                byte[] out = res.getBytes(StandardCharsets.UTF_8);
                DatagramPacket reply = new DatagramPacket(out, out.length, packet.getAddress(), packet.getPort());
                socket.send(reply);

            } catch (Exception e) {
                String err = "Invalid input! Format: <h1> <m1> <h2> <m2>";
                byte[] out = err.getBytes(StandardCharsets.UTF_8);
                DatagramPacket reply = new DatagramPacket(out, out.length, packet.getAddress(), packet.getPort());
                socket.send(reply);
            }
        }
    }
}
