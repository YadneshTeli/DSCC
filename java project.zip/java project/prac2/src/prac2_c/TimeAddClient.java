package prac2_c;

import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class TimeAddClient {
    public static final int SERVER_PORT = 9902;

    public static void main(String[] args) throws Exception {
         
        Scanner sc = new Scanner(System.in);
        DatagramSocket socket = new DatagramSocket();

        System.out.print("Enter first time (hours minutes): ");
        int h1 = sc.nextInt(), m1 = sc.nextInt();
        System.out.print("Enter second time (hours minutes): ");
        int h2 = sc.nextInt(), m2 = sc.nextInt();
        sc.nextLine(); // consume newline

        String req = h1 + " " + m1 + " " + h2 + " " + m2;
        byte[] data = req.getBytes(StandardCharsets.UTF_8);
        InetAddress addr = InetAddress.getByName("localhost");
        DatagramPacket packet = new DatagramPacket(data, data.length, addr, SERVER_PORT);
        socket.send(packet);

        byte[] buf = new byte[256];
        DatagramPacket reply = new DatagramPacket(buf, buf.length);
        socket.receive(reply);

        String res = new String(reply.getData(), 0, reply.getLength(), StandardCharsets.UTF_8);
        System.out.println("Server says: " + res);

        socket.close();
    }
}
