package prac2_b;

import java.net.*; 
import java.nio.charset.StandardCharsets; 
import java.time.LocalDateTime; 
import java.time.format.DateTimeFormatter; 
public class DateTimeServer { 
	public static final int PORT = 9876; 
	public static final int BUFFER_SIZE = 1024;
	public static void main(String[] args) {
		try (DatagramSocket socket = new DatagramSocket(PORT)) {
			  
			System.out.println("DateTime Server started on port " + PORT); 
			byte[] buffer = new byte[BUFFER_SIZE]; 
			while (true) { 
				DatagramPacket requestPacket = new DatagramPacket(buffer, buffer.length); 
				socket.receive(requestPacket);  // wait for request 
				String request = new String(requestPacket.getData(), 0, requestPacket.getLength(), 
				StandardCharsets.UTF_8).trim(); 
				System.out.println("Received request: " + request); 
				// Simple protocol: If request is "GET_DATETIME", reply with current datetime 
				String response; 
				if ("GET_DATETIME".equalsIgnoreCase(request)) { 
				LocalDateTime now = LocalDateTime.now(); 
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"); 
				response = "OK " + now.format(formatter); 
				} else { 
					response = "ERR Unknown request"; 
				} 
				byte[] respBytes = response.getBytes(StandardCharsets.UTF_8); 
				DatagramPacket responsePacket = new DatagramPacket( 
				respBytes, respBytes.length, 
				requestPacket.getAddress(), 
				requestPacket.getPort() 
				); 
				socket.send(responsePacket); 
				System.out.println("Sent response: " + response); 
			}
		}catch (Exception e) { 
			e.printStackTrace(); 
		}
	}
}
