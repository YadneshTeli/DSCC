package prac2_b;

import java.net.*;
import java.nio.charset.StandardCharsets;
public class DateTimeClient {
	public static final int SERVER_PORT=9876;
	public static final int BUFFER_SIZE=1024;
	public static final int TIMEOUT=2000;//ms
	public static final int MAX_RETRIES=3;
	public static void main(String[] args) {
		  
		try (DatagramSocket socket = new DatagramSocket()) {
			socket.setSoTimeout(TIMEOUT);
			InetAddress serverAddress=InetAddress.getByName("localhost");
			String request="GET_DATETIME";
			byte[] reqBytes=request.getBytes(StandardCharsets.UTF_8);
			DatagramPacket requestPacket=new DatagramPacket(reqBytes,reqBytes.length,serverAddress,SERVER_PORT);
			byte[] buffer=new byte[BUFFER_SIZE];
			DatagramPacket responsePacket=new DatagramPacket(buffer,buffer.length);
			boolean receivedResponse=false;
			int attempts=0;
			while(!receivedResponse && attempts < MAX_RETRIES) {
				try {
					attempts++;
					System.out.println("Sending request to server(try "+attempts+")");
					socket.send(requestPacket);
					socket.receive(responsePacket);
					String response=new String(responsePacket.getData(),0,responsePacket.getLength(),StandardCharsets.UTF_8);
					System.out.println("Response from server:"+response);
					receivedResponse=true;
				}catch(SocketTimeoutException e) {
					System.out.println("No response from server,timeout.");
					if(attempts==MAX_RETRIES) {
						System.out.println("Max retries reached, giving up.");
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}

