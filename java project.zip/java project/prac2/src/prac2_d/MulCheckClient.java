package prac2_d;

import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class MulCheckClient {
    public static final int SERVER_PORT = 9903;

    public static void main(String[] args) throws Exception {
         
        Scanner sc = new Scanner(System.in);
        DatagramSocket socket = new DatagramSocket();

        System.out.print("Enter two numbers: ");
        int a = sc.nextInt();
        int b = sc.nextInt();
        sc.nextLine();

        String req = a + " " + b;
        byte[] data = req.getBytes(StandardCharsets.UTF_8);
        InetAddress addr = InetAddress.getByName("localhost");
        DatagramPacket packet = new DatagramPacket(data, data.length, addr, SERVER_PORT);
        socket.send(packet);

        byte[] buf = new byte[256];
        DatagramPacket reply = new DatagramPacket(buf, buf.length);
        socket.receive(reply);

        String res = new String(reply.getData(), 0, reply.getLength(), StandardCharsets.UTF_8);
        System.out.println("Server says: " + res);

        // Check condition
        try {
            int result = Integer.parseInt(res.replaceAll("\\D+", ""));
            if (result > 250)
                System.out.println("Result is greater than 250.");
            else
                System.out.println("Result is less than or equal to 250.");
        } catch (Exception e) {
            System.out.println("Error: " + res);
        }

        socket.close();
    }
}
