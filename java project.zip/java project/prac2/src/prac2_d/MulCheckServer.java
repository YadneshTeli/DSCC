package prac2_d;

import java.net.*;
import java.nio.charset.StandardCharsets;

public class MulCheckServer {
    public static final int PORT = 9903;

    public static void main(String[] args) throws Exception {
         
        DatagramSocket socket = new DatagramSocket(PORT);
        byte[] buf = new byte[256];
        System.out.println("MulCheckServer listening on port " + PORT);

        while (true) {
            DatagramPacket packet = new DatagramPacket(buf, buf.length);
            socket.receive(packet);

            String req = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8).trim();
            System.out.println("Received: " + req);

            try {
                String[] parts = req.split("\\s+");
                int a = Integer.parseInt(parts[0]);
                int b = Integer.parseInt(parts[1]);
                int result = a * b;

                String res = "Multiplication = " + result;
                byte[] out = res.getBytes(StandardCharsets.UTF_8);
                DatagramPacket reply = new DatagramPacket(out, out.length, packet.getAddress(), packet.getPort());
                socket.send(reply);

            } catch (Exception e) {
                String err = "Invalid input! Format: <num1> <num2>";
                byte[] out = err.getBytes(StandardCharsets.UTF_8);
                DatagramPacket reply = new DatagramPacket(out, out.length, packet.getAddress(), packet.getPort());
                socket.send(reply);
            }
        }
    }
}
