package prac2_f;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class NumberClient {
    public static void main(String[] args) {
         

        try (Socket socket = new Socket("localhost", 5000)) {
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
            DataInputStream dis = new DataInputStream(socket.getInputStream());
            Scanner sc = new Scanner(System.in);

            System.out.print("Enter a number: ");
            int num = sc.nextInt();
            dos.writeInt(num); // send number to server

            String result = dis.readUTF(); // receive odd/even
            System.out.println("Number is " + result);

            if (result.equals("Even")) {
                System.out.println("Table of " + num + ":");
                for (int i = 1; i <= 10; i++) {
                    System.out.println(num + " x " + i + " = " + (num * i));
                }
            }

            sc.close();
            dis.close();
            dos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
