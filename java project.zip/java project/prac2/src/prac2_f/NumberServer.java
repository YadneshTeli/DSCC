package prac2_f;

import java.io.*;
import java.net.*;

public class NumberServer {
    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(5000)) {
            System.out.println("Server is running...");
            Socket socket = server.accept();

            DataInputStream dis = new DataInputStream(socket.getInputStream());
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

            int num = dis.readInt();
            String result = (num % 2 == 0) ? "Even" : "Odd";

            dos.writeUTF(result); // send result to client

            dis.close();
            dos.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
