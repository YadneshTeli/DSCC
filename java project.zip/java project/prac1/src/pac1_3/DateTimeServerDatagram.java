package pac1_3;

import java.net.*;
import java.time.*;
import java.nio.charset.StandardCharsets;

public class DateTimeServerDatagram {
    public static final int PORT = 9877;
    public static final int BUFFER_SIZE = 1024;

    public static void main(String[] args) {

    	try (DatagramSocket socket = new DatagramSocket(PORT)) {
            System.out.println("Date-Time RPC Server started on port " + PORT);

            byte[] buffer = new byte[BUFFER_SIZE];
            while (true) {
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                socket.receive(request);

                String reqMsg = new String(request.getData(), 0, request.getLength(), StandardCharsets.UTF_8);
                System.out.println("Received: " + reqMsg);

                String response = "";
                switch (reqMsg.trim().toUpperCase()) {
                    case "DATE":
                        response = "Date: " + LocalDate.now();
                        break;
                    case "TIME":
                        response = "Time: " + LocalTime.now();
                        break;
                    default:
                        response = "Invalid request. Use DATE or TIME.";
                }

                byte[] respBytes = response.getBytes(StandardCharsets.UTF_8);
                DatagramPacket reply = new DatagramPacket(respBytes, respBytes.length,
                        request.getAddress(), request.getPort());
                socket.send(reply);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
