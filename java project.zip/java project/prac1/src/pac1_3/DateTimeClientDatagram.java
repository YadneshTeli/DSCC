package pac1_3;

import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class DateTimeClientDatagram {
    public static final int SERVER_PORT = 9877;

    public static void main(String[] args) {
         
        try (DatagramSocket socket = new DatagramSocket();
             Scanner sc = new Scanner(System.in)) {

            System.out.print("Enter request (DATE or TIME): ");
            String req = sc.nextLine();

            byte[] sendData = req.getBytes(StandardCharsets.UTF_8);
            InetAddress serverAddr = InetAddress.getByName("localhost");

            DatagramPacket packet = new DatagramPacket(sendData, sendData.length, serverAddr, SERVER_PORT);
            socket.send(packet);

            byte[] buffer = new byte[1024];
            DatagramPacket response = new DatagramPacket(buffer, buffer.length);
            socket.receive(response);

            String reply = new String(response.getData(), 0, response.getLength(), StandardCharsets.UTF_8);
            System.out.println("Server says: " + reply);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
