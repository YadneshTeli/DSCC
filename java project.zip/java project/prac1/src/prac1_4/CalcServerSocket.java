package prac1_4;

import java.io.*;
import java.net.*;

public class CalcServerSocket {
    public static void main(String[] args) {
         
        try (ServerSocket serverSocket = new ServerSocket(9878)) {
            System.out.println("Calculator RPC Server (ServerSocket) started on port 9878");

            while (true) {
                Socket socket = serverSocket.accept();
                new Thread(new CalcHandler(socket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class CalcHandler implements Runnable {
    private Socket socket;

    CalcHandler(Socket socket) {
        this.socket = socket;
    }

    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            String request = in.readLine();
            System.out.println("Received: " + request);

            String[] parts = request.trim().split("\\s+");
            if (parts.length != 3) {
                out.println("ERR Invalid format");
                return;
            }

            double a = Double.parseDouble(parts[1]);
            double b = Double.parseDouble(parts[2]);
            String op = parts[0].toUpperCase();
            double result;

            switch (op) {
                case "ADD": result = a + b; break;
                case "SUB": result = a - b; break;
                case "MUL": result = a * b; break;
                case "DIV":
                    if (b == 0) { out.println("ERR Divide by zero"); return; }
                    result = a / b; break;
                default: out.println("ERR Unknown operation"); return;
            }

            out.println("Result: " + result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
