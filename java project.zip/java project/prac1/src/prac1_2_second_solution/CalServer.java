package prac1_2_second_solution;

import java.net.*; 
import java.nio.charset.StandardCharsets; 
 
public class CalServer { 
    public static final int PORT = 9876; 
    public static final int BUFFER_SIZE = 1024; 
    public static void main(String[] args) { 
        DatagramSocket socket = null; 
        try { 
        	  
            socket = new DatagramSocket(PORT); 
            System.out.println("Calculator RPC Server started on port " + PORT); 
            byte[] buffer = new byte[BUFFER_SIZE]; 
            while (true) { 
                DatagramPacket requestPacket = new DatagramPacket(buffer, buffer.length); 
                socket.receive(requestPacket); 
                String request = new String(requestPacket.getData(), 0, requestPacket.getLength(), 
StandardCharsets.UTF_8).trim(); 
                System.out.println("Received: " + request); 
                String response = processRequest(request); 
                byte[] responseBytes = response.getBytes(StandardCharsets.UTF_8); 
                DatagramPacket responsePacket = new DatagramPacket(responseBytes, 
responseBytes.length, 
                        requestPacket.getAddress(), requestPacket.getPort()); 
                socket.send(responsePacket); 
                System.out.println("Sent response: " + response); 
            } 
        } catch (Exception e) { 
            e.printStackTrace(); 
        } finally { 
            if (socket != null && !socket.isClosed()) 
                socket.close(); 
        } 
    } 
 
    private static String processRequest(String req)  
    {
    	String[] parts = req.split("\\s+"); 
    	if (parts.length != 3) { 
    	return "ERR Invalid request format"; 
    	} 
    	String op = parts[0].toUpperCase(); 
    	double a, b; 
    	try { 
    	a = Double.parseDouble(parts[1]); 
    	b = Double.parseDouble(parts[2]); 
    	} catch (NumberFormatException e) { 
    	return "ERR Operands must be numbers"; 
    	} 
    	double result; 
    	switch (op)  
    	{ 
    	case "ADD": result = a + b; break; 
    	case "SUB": result = a - b; break; 
    	case "MUL": result = a * b; break; 
    	case "DIV": 
    	if (b == 0) return "ERR Division by zero"; 
    	result = a / b; 
    	break; 
    	case "MOD": 
    	if (b == 0) return "ERR Division by zero for MOD"; 
    	result = a % b; 
    	break; 
    	default: 
    	return "ERR Unknown operation"; 
    	} 
    	return "OK " + result; 
    	} 
    } 

