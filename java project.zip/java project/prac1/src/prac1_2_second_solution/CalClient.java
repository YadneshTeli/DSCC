package prac1_2_second_solution;
import java.net.*;
import java.nio.charset.StandardCharsets; 
import java.util.Scanner; 
public class CalClient  
{ 
	public static final int SERVER_PORT = 9876; 
    public static final int BUFFER_SIZE = 1024; 
    public static final int TIMEOUT = 2000; // ms 
    public static final int MAX_RETRIES = 3; 
 
    public static void main(String[] args) {
    	Scanner scanner = new Scanner(System.in); 
    	  
        try (DatagramSocket socket = new DatagramSocket()) {
        	 socket.setSoTimeout(TIMEOUT); 
             System.out.print("Enter operation (ADD, SUB, MUL, DIV, MOD): "); 
             String op = scanner.nextLine().trim().toUpperCase(); 
             System.out.print("Enter first number: "); 
             String a = scanner.nextLine().trim(); 
             System.out.print("Enter second number: "); 
             String b = scanner.nextLine().trim(); 
             // Format request string 
             String request = op + " " + a + " " + b; 
             byte[] requestBytes = request.getBytes(StandardCharsets.UTF_8); 
             InetAddress serverAddress = InetAddress.getByName("localhost"); 
             DatagramPacket requestPacket = new DatagramPacket(requestBytes, 
 requestBytes.length, serverAddress, SERVER_PORT); 
             byte[] buffer = new byte[BUFFER_SIZE]; 
             DatagramPacket responsePacket = new DatagramPacket(buffer, buffer.length); 
             boolean receivedResponse = false; 
             int attempts = 0; 
             while (!receivedResponse && attempts < MAX_RETRIES) {
            	 try { 
            		 attempts++; 
                     System.out.println("Sending request (try " + attempts + "): " + request); 
                     socket.send(requestPacket); 
                     socket.receive(responsePacket); // wait for server response 
                     String response = new String(responsePacket.getData(), 0, 
 responsePacket.getLength(), StandardCharsets.UTF_8); 
                     System.out.println("Response from server: " + response); 
                     receivedResponse = true; 
                 } catch (SocketTimeoutException e) { 
                     System.out.println("No response, timeout after " + TIMEOUT + "ms."); 
                     if (attempts == MAX_RETRIES) { 
                         System.out.println("Max retries reached. Giving up."); 
                     } else { 
                         System.out.println("Retrying..."); 
                     }
                 }
             }
             
        }catch (Exception e) { 
            e.printStackTrace(); 
        } finally { 
            scanner.close(); 
        } 
    }
}
