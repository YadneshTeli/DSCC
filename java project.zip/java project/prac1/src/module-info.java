/**
 * 
 */
/**
 * 
 */
module prac1 {
}