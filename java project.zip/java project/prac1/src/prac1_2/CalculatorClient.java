package prac1_2;
import java.net.*; 
import java.util.Scanner; 
public class CalculatorClient { 
	public static void main(String[] args) { 
		try { 
			  
			DatagramSocket socket = new DatagramSocket(); 
			InetAddress serverAddress = InetAddress.getByName("localhost"); 
			Scanner sc = new Scanner(System.in); 
			System.out.print("Enter request (e.g., ADD 5 3): "); 
			String request = sc.nextLine(); 
			byte[] sendData = request.getBytes(); 
			DatagramPacket sendPacket = new DatagramPacket( 
			sendData, sendData.length, serverAddress, 9876); 
			socket.send(sendPacket); 
			byte[] buffer = new byte[1024]; 
			DatagramPacket receivePacket = new DatagramPacket(buffer, buffer.length); 
			socket.receive(receivePacket); 
			String response = new String(receivePacket.getData(), 0, receivePacket.getLength()); 
			System.out.println("Server says: " + response); 
			sc.close(); 
			socket.close(); 
			} catch (Exception e) { 
				e.printStackTrace(); 
				} 
		} 
}
