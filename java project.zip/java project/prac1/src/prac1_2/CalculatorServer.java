package prac1_2;

import java.net.*; 
public class CalculatorServer { 
	public static void main(String[] args) { 
		try { 
			DatagramSocket socket = new DatagramSocket(9876); 
			byte[] buffer = new byte[1024]; 
			System.out.println("Server started. Waiting for requests..."); 
			while (true) { 
			DatagramPacket packet = new DatagramPacket(buffer, buffer.length); 
			socket.receive(packet); 
			String request = new String(packet.getData(), 0, packet.getLength()); 
			String response = calculate(request); 
			byte[] sendData = response.getBytes();
			DatagramPacket sendPacket = new DatagramPacket( 
			sendData, sendData.length, packet.getAddress(), packet.getPort()); 
			socket.send(sendPacket); 
			}
			} catch (Exception e) { 
				e.printStackTrace(); 
			}
} 

private static String calculate(String request) { 
	// request format: "ADD 5 3" 
	String[] parts = request.trim().split("\\s+"); 
	if (parts.length != 3) return "Error: Invalid format"; 
	String op = parts[0].toUpperCase(); 
	double a = Double.parseDouble(parts[1]); 
	double b = Double.parseDouble(parts[2]); 
	double result; 
	switch (op)  
	{ 
		case "ADD": result = a + b; break; 
		case "SUB": result = a - b; break; 
		case "MUL": result = a * b; break; 
		case "DIV":  
			if (b == 0) return "Error: Divide by zero"; 
			result = a / b;  
			break; 
		default: return "Error: Unknown operation"; 
	} 
	return "Result: " + result; 
	} 
}
