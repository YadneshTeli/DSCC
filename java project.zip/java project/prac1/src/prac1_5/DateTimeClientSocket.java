package prac1_5;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class DateTimeClientSocket {
    public static void main(String[] args) {
         
        try (Socket socket = new Socket("localhost", 9879);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             Scanner sc = new Scanner(System.in)) {

            System.out.print("Enter request (DATE or TIME): ");
            String req = sc.nextLine();
            out.println(req);

            String response = in.readLine();
            System.out.println("Server says: " + response);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
