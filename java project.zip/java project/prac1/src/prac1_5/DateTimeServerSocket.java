package prac1_5;

import java.io.*;
import java.net.*;
import java.time.*;

public class DateTimeServerSocket {
    public static void main(String[] args) {
         
        try (ServerSocket serverSocket = new ServerSocket(9879)) {
            System.out.println("Date-Time RPC Server (ServerSocket) started on port 9879");

            while (true) {
                Socket socket = serverSocket.accept();
                new Thread(new DateHandler(socket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class DateHandler implements Runnable {
    private Socket socket;

    DateHandler(Socket socket) {
        this.socket = socket;
    }

    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            String request = in.readLine();
            System.out.println("Received: " + request);

            switch (request.trim().toUpperCase()) {
                case "DATE": out.println("Date: " + LocalDate.now()); break;
                case "TIME": out.println("Time: " + LocalTime.now()); break;
                default: out.println("Invalid Request. Use DATE or TIME."); break;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
