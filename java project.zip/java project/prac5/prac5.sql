CREATE DATABASE Library;
USE Library;
CREATE TABLE Book (
    Book_id INT PRIMARY KEY,
    Book_name VARCHAR(100),
    Book_author VARCHAR(100)
);

INSERT INTO Book (Book_id, Book_name, Book_author) VALUES (1, 'Distributed System ', 'Robert C. Martin'), (2, 'Effective Java', 'Joshua Bloch'),(3, 'cloude Computing', 'Peter Bloch') 
ON DUPLICATE KEY UPDATE Book_name = VALUES(Book_name),
Book_author = VALUES(Book_author);
