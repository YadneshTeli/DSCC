package RMI;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import DAO.Book;

public interface LibraryService extends Remote {
    boolean addBook(Book book) throws RemoteException;
    Book getBookById(int id) throws RemoteException;
    List<Book> getAllBooks() throws RemoteException;
}
