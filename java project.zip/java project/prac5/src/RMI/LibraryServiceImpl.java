package RMI;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import DAO.Book;
import DataBase.DBUtil;

@SuppressWarnings("serial")
public class LibraryServiceImpl extends UnicastRemoteObject implements LibraryService {

    public LibraryServiceImpl() throws RemoteException {
        super();
    }

    @Override
    public boolean addBook(Book book) throws RemoteException {
        String sql = "INSERT INTO Book (Book_id, Book_name, Book_author) VALUES (?, ?, ?) "
                   + "ON DUPLICATE KEY UPDATE Book_name = VALUES(Book_name), "
                   + "Book_author = VALUES(Book_author)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, book.getBookId());
            ps.setString(2, book.getBookName());
            ps.setString(3, book.getBookAuthor());
            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RemoteException("DB error in addBook", e);
        }
    }

    @Override
    public Book getBookById(int id) throws RemoteException {
        String sql = "SELECT Book_id, Book_name, Book_author FROM Book WHERE Book_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Book(
                        rs.getInt("Book_id"),
                        rs.getString("Book_name"),
                        rs.getString("Book_author")
                    );
                }
                return null;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RemoteException("DB error in getBookById", e);
        }
    }

    @Override
    public List<Book> getAllBooks() throws RemoteException {
        String sql = "SELECT Book_id, Book_name, Book_author FROM Book ORDER BY Book_id";
        List<Book> list = new ArrayList<>();

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new Book(
                    rs.getInt("Book_id"),
                    rs.getString("Book_name"),
                    rs.getString("Book_author")
                ));
            }
            return list;

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RemoteException("DB error in getAllBooks", e);
        }
    }
}

