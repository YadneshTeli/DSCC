/**
 * 
 */
/**
 * 
 */
module prac5 {
	requires java.rmi;
	opens Server to java.rmi;
	opens RMI to java.rmi;
	opens Client to java.rmi;
	requires java.sql;
}