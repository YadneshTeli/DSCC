package Server;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import RMI.LibraryService;
import RMI.LibraryServiceImpl;

public class LibraryServer {
    public static void main(String[] args) {
        try {
            try {
                LocateRegistry.createRegistry(1099);
                System.out.println("RMI registry started on port 1099");
            } catch (Exception e) {
                System.out.println("RMI registry may already be running.");
            }

            LibraryService service = new LibraryServiceImpl();
            Registry registry = LocateRegistry.getRegistry();
            registry.rebind("LibraryService", service);

            System.out.println("LibraryService bound. Server is ready.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
