package Client;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;

import DAO.Book;
import RMI.LibraryService;

public class LibraryClient {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            LibraryService service = (LibraryService) registry.lookup("LibraryService");

            // Optional: add a book remotely
            service.addBook(new Book(4, "Design Patterns", "Gamma, Vlissides"));

            // Fetch by ID
            Book b = service.getBookById(4);
            System.out.println("getBookById() => " + b);

            // Fetch all
            List<Book> all = service.getAllBooks();
            System.out.println("All books:");
            for (Book bk : all) {
                System.out.println("  " + bk);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

