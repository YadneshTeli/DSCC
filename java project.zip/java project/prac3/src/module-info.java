/**
 * 
 */
/**
 * 
 */
module prac3 {
	requires java.rmi;
	opens prac3_a to java.rmi;
	opens prac3_b to java.rmi;
	opens prac3_c to java.rmi;
	opens prac3_d to java.rmi;
}