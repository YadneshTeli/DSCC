package prac3_a;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class AdditionClient {
    public static void main(String[] args) {
     
        try {
            Registry reg = LocateRegistry.getRegistry("localhost", 1099);
            AdditionInterface stub = (AdditionInterface) reg.lookup("AddService");

            Scanner sc = new Scanner(System.in);
            System.out.print("Enter first number: ");
            int a = sc.nextInt();
            System.out.print("Enter second number: ");
            int b = sc.nextInt();

            int result = stub.add(a, b);
            System.out.println("Result from Server: " + result);

            sc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

