package prac3_a;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class AdditionServer extends UnicastRemoteObject implements AdditionInterface {

    protected AdditionServer() throws java.rmi.RemoteException {
        super();
    }

    public int add(int a, int b) {
        int sum = a + b;
        System.out.println("Server received numbers: " + a + " and " + b);
        System.out.println("Server sending result: " + sum);
        return sum;
    }

    public static void main(String[] args) {
          
        try {
            Registry reg = LocateRegistry.createRegistry(1099);
            reg.rebind("AddService", new AdditionServer());
            System.out.println("Server is ready...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

