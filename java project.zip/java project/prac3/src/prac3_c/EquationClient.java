package prac3_c;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class EquationClient {
    public static void main(String[] args) {
          
        try {
            Registry reg = LocateRegistry.getRegistry("localhost", 1099);
            EquationInterface stub = (EquationInterface) reg.lookup("EquationService");

            Scanner sc = new Scanner(System.in);
            System.out.print("Enter value of a: ");
            int a = sc.nextInt();
            System.out.print("Enter value of b: ");
            int b = sc.nextInt();

            int result = stub.solve(a, b);
            System.out.println("Result from Server: (a+b)² = " + result);

            sc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

