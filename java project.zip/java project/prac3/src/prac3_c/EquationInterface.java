package prac3_c;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface EquationInterface extends Remote {
    int solve(int a, int b) throws RemoteException;
}
