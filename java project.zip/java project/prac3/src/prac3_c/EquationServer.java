package prac3_c;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class EquationServer extends UnicastRemoteObject implements EquationInterface {

    protected EquationServer() throws java.rmi.RemoteException {
        super();
    }

    public int solve(int a, int b) {
        int result = (a * a) + (2 * a * b) + (b * b);
        System.out.println("Server received a=" + a + " b=" + b);
        System.out.println("Server sending result: " + result);
        return result;
    }

    public static void main(String[] args) {
          
        try {
            Registry reg = LocateRegistry.createRegistry(1099);
            reg.rebind("EquationService", new EquationServer());
            System.out.println("Server is ready...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
