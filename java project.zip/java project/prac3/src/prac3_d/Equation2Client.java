package prac3_d;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class Equation2Client {
    public static void main(String[] args) {
          
        try {
            Registry reg = LocateRegistry.getRegistry("localhost", 1099);
            Equation2Interface stub = (Equation2Interface) reg.lookup("Equation2Service");

            Scanner sc = new Scanner(System.in);
            System.out.print("Enter value of a: ");
            int a = sc.nextInt();
            System.out.print("Enter value of b: ");
            int b = sc.nextInt();

            String result = stub.solveBoth(a, b);
            System.out.println("Result from Server: " + result);

            sc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

