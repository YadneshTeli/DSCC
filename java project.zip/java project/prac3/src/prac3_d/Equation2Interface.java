package prac3_d;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Equation2Interface extends Remote {
    String solveBoth(int a, int b) throws RemoteException;
}
