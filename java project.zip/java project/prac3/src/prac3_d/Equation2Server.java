package prac3_d;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class Equation2Server extends UnicastRemoteObject implements Equation2Interface {

    protected Equation2Server() throws java.rmi.RemoteException {
        super();
    }

    public String solveBoth(int a, int b) {
        int plus = (a * a) + (2 * a * b) + (b * b);
        int minus = (a * a) - (2 * a * b) + (b * b);
        System.out.println("Server received a=" + a + " b=" + b);
        System.out.println("Server sending results: (a+b)²=" + plus + ", (a−b)²=" + minus);
        return "(a+b)² = " + plus + ", (a−b)² = " + minus;
    }

    public static void main(String[] args) {
          
        try {
            Registry reg = LocateRegistry.createRegistry(1099);
            reg.rebind("Equation2Service", new Equation2Server());
            System.out.println("Server is ready...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

