package prac3_b;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Date;

public class TimeServer extends UnicastRemoteObject implements TimeInterface {

    protected TimeServer() throws java.rmi.RemoteException {
        super();
    }

    public String getDateTime() {
        String time = new Date().toString();
        System.out.println("Server sending current date & time: " + time);
        return time;
    }

    public static void main(String[] args) {
          
        try {
            Registry reg = LocateRegistry.createRegistry(1099);
            reg.rebind("TimeService", new TimeServer());
            System.out.println("Server is ready...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
