package prac3_b;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class TimeClient {
    public static void main(String[] args) {
          
        try {
            Registry reg = LocateRegistry.getRegistry("localhost", 1099);
            TimeInterface stub = (TimeInterface) reg.lookup("TimeService");

            String response = stub.getDateTime();
            System.out.println("Date and Time from Server: " + response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

