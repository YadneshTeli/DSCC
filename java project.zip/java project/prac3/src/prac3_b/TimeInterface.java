package prac3_b;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface TimeInterface extends Remote {
    String getDateTime() throws RemoteException;
}

