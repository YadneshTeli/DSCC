/**
 * 
 */
/**
 * 
 */
module prac6 {
	requires java.rmi;
	requires java.sql;
	exports prac6 to java.rmi;
}