package prac6;

import java.rmi.registry.*;
import java.util.List;
import prac6.Student;
import prac6.StudentService;

public class StudentClient {
public static void main(String[] args) {
try{
Registry reg=LocateRegistry.getRegistry("localhost",1099);
StudentService service=(StudentService)reg.lookup("StudentService");

service.addStudent(new Student(4,"Kunal","CSE",88.23,"kunal@gmail.com"));

Student s=service.getStudentById(4);
System.out.println("Student fetched: "+s);

List<Student> all=service.getAllStudents();
for(Student st:all){ System.out.println(st); }

}catch(Exception e){ e.printStackTrace(); }
}
}

