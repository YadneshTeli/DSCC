package prac6;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import prac6.Student;
import prac6.DBUtil;

public class StudentServiceImpl extends UnicastRemoteObject implements StudentService {

public StudentServiceImpl() throws RemoteException { super(); }

@Override
public boolean addStudent(Student s) throws RemoteException {
String sql="INSERT INTO student_data VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE NAME=?,BRANCH=?,PERCENTAGE=?,EMAIL=?";
try(Connection con=DBUtil.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){
ps.setInt(1,s.getId());
ps.setString(2,s.getName());
ps.setString(3,s.getBranch());
ps.setDouble(4,s.getPercentage());
ps.setString(5,s.getEmail());

ps.setString(6,s.getName());
ps.setString(7,s.getBranch());
ps.setDouble(8,s.getPercentage());
ps.setString(9,s.getEmail());
ps.executeUpdate();
return true;
}catch(Exception e){ throw new RemoteException("error addStudent",e); }
}

@Override
public Student getStudentById(int id) throws RemoteException {
String sql="SELECT * FROM student_data WHERE ID=?";
try(Connection con=DBUtil.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){
ps.setInt(1,id);
try(ResultSet rs=ps.executeQuery()){
if(rs.next()){
return new Student(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getString(5));
}
}
return null;
}catch(Exception e){ throw new RemoteException("error getStudent",e); }
}

@Override
public List<Student> getAllStudents() throws RemoteException {
List<Student> list=new ArrayList<>();
try(Connection con=DBUtil.getConnection(); PreparedStatement ps=con.prepareStatement("SELECT * FROM student_data"); ResultSet rs=ps.executeQuery()){
while(rs.next()){
list.add(new Student(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getString(5)));
}
}catch(Exception e){ throw new RemoteException("error allStudents",e); }
return list;
}
}

