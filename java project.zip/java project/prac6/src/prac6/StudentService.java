package prac6;

import java.rmi.*;
import java.util.List;
import prac6.Student;

public interface StudentService extends Remote {

boolean addStudent(Student s) throws RemoteException;
Student getStudentById(int id) throws RemoteException;
List<Student> getAllStudents() throws RemoteException;

}
