package prac6;

import java.io.Serializable;

public class Student implements Serializable {
private static final long serialVersionUID = 1L;

private int id;
private String name;
private String branch;
private double percentage;
private String email;

public Student(){}

public Student(int id, String name, String branch, double percentage, String email){
this.id=id;
this.name=name;
this.branch=branch;
this.percentage=percentage;
this.email=email;
}

public int getId(){ return id; }
public String getName(){ return name; }
public String getBranch(){ return branch; }
public double getPercentage(){ return percentage; }
public String getEmail(){ return email; }

public void setId(int id){ this.id=id; }
public void setName(String name){ this.name=name; }
public void setBranch(String branch){ this.branch=branch; }
public void setPercentage(double percentage){ this.percentage=percentage; }
public void setEmail(String email){ this.email=email; }

@Override
public String toString(){
return id+" "+name+" "+branch+" "+percentage+" "+email;
}
}
