package prac6;

import java.rmi.registry.*;
import prac6.StudentService;
import prac6.StudentServiceImpl;

public class StudentServer {
public static void main(String[] args) {
try{
LocateRegistry.createRegistry(1099);
StudentService service=new StudentServiceImpl();
Registry reg=LocateRegistry.getRegistry();
reg.rebind("StudentService",service);
System.out.println("StudentService Server Ready");
}catch(Exception e){ e.printStackTrace(); }
}
}
