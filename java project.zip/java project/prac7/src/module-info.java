/**
 * 
 */
/**
 * 
 */
module prac7 {
	requires java.rmi;
	requires java.sql;
	exports prac7 to java.rmi;
}