package prac7;

import java.rmi.registry.*;
import java.text.SimpleDateFormat;
import java.util.List;
import prac7.Bill;
import prac7.BillService;

public class BillClient {
public static void main(String[] args) {
try{
Registry reg=LocateRegistry.getRegistry("localhost",1099);
BillService service=(BillService)reg.lookup("BillService");

SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
service.addBill(new Bill("Mohan",sdf.parse("2025-03-25"),3000.00));

Bill b=service.getBill("Mohan");
System.out.println("Fetched : "+b);

List<Bill> all=service.getAllBills();
System.out.println("All Bills:");
for(Bill bb:all){ System.out.println(bb); }

}catch(Exception e){ e.printStackTrace(); }
}
}
