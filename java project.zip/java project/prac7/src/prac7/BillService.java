package prac7;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import prac7.Bill;

public interface BillService extends Remote {
boolean addBill(Bill b) throws RemoteException;
Bill getBill(String consumerName) throws RemoteException;
List<Bill> getAllBills() throws RemoteException;
}

