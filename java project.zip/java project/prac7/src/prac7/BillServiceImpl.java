package prac7;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.sql.*;
import java.util.*;
import prac7.Bill;
import prac7.DBUtil;

public class BillServiceImpl extends UnicastRemoteObject implements BillService{
public BillServiceImpl() throws RemoteException { super(); }

@Override
public boolean addBill(Bill b) throws RemoteException {
String sql="INSERT INTO Bill VALUES(?,?,?) ON DUPLICATE KEY UPDATE bill_due_date=?, bill_amount=?";
try(Connection con=DBUtil.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){
ps.setString(1,b.getConsumerName());
ps.setDate(2,new java.sql.Date(b.getBillDueDate().getTime()));
ps.setDouble(3,b.getBillAmount());
ps.setDate(4,new java.sql.Date(b.getBillDueDate().getTime()));
ps.setDouble(5,b.getBillAmount());
ps.executeUpdate();
return true;
}catch(Exception e){ throw new RemoteException("addBill error",e); }
}

@Override
public Bill getBill(String consumerName) throws RemoteException {
String sql="SELECT * FROM Bill WHERE consumer_name=?";
try(Connection con=DBUtil.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){
ps.setString(1,consumerName);
try(ResultSet rs=ps.executeQuery()){
if(rs.next()){
return new Bill(rs.getString(1),rs.getDate(2),rs.getDouble(3));
}
}
}catch(Exception e){ throw new RemoteException("getBill error",e); }
return null;
}

@Override
public List<Bill> getAllBills() throws RemoteException {
List<Bill> list=new ArrayList<>();
try(Connection con=DBUtil.getConnection(); PreparedStatement ps=con.prepareStatement("SELECT * FROM Bill"); ResultSet rs=ps.executeQuery()){
while(rs.next()){
list.add(new Bill(rs.getString(1),rs.getDate(2),rs.getDouble(3)));
}
}catch(Exception e){ throw new RemoteException("getAllBills error",e); }
return list;
}
}
