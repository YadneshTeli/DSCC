package prac7;

import java.io.Serializable;
import java.util.Date;

public class Bill implements Serializable {
private static final long serialVersionUID=1L;

private String consumerName;
private Date billDueDate;
private double billAmount;

public Bill(){}

public Bill(String cn, Date due, double amt){
this.consumerName=cn;
this.billDueDate=due;
this.billAmount=amt;
}

public String getConsumerName(){ return consumerName; }
public Date getBillDueDate(){ return billDueDate; }
public double getBillAmount(){ return billAmount; }

public void setConsumerName(String n){ consumerName=n; }
public void setBillDueDate(Date d){ billDueDate=d; }
public void setBillAmount(double a){ billAmount=a; }

@Override
public String toString(){
return consumerName+" "+billDueDate+" "+billAmount;
}
}
