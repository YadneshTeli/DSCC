package prac7;

import java.rmi.registry.*;
import prac7.BillService;
import prac7.BillServiceImpl;

public class BillServer {
public static void main(String[] args) {
try{
LocateRegistry.createRegistry(1099);
Registry reg=LocateRegistry.getRegistry();
reg.rebind("BillService", new BillServiceImpl());
System.out.println("BillService Server Ready");
}catch(Exception e){ e.printStackTrace(); }
}
}

