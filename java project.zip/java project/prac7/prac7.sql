CREATE DATABASE ElecrticBill;
USE ElecrticBill;
CREATE TABLE Bill(
  consumer_name VARCHAR(50) PRIMARY KEY,
  bill_due_date DATE,
  bill_amount DOUBLE
);
INSERT INTO Bill VALUES
('Anant','2025-03-15',1200.50),
('Rohit','2025-03-16',2400.00),
('Sneha','2025-03-18',1800.75)ON DUPLICATE KEY UPDATE
bill_due_date=VALUES(bill_due_date),
bill_amount=VALUES(bill_amount);
