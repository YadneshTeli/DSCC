package prac8;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Random;
import java.util.Scanner;

public class TokenRingEclipse {
    // Simple serializable-like Token (no actual serialization needed here)
    static class Token {
        private int passCount;

        Token(int init) {
            this.passCount = init;
        }

        int getPassCount() {
            return passCount;
        }

        void increment() {
            passCount++;
        }

        @Override
        public String toString() {
            return "Token(pass=" + passCount + ")";
        }
    }

    // Node thread
    static class Node implements Runnable {
        private final int id;
        private final BlockingQueue<Token> myQueue;
        private final BlockingQueue<Token> nextQueue;
        private final AtomicInteger globalPassCounter;
        private final int maxPasses;
        private final Random rnd = new Random();
        private final AtomicBoolean shutdownRequested;

        Node(int id, BlockingQueue<Token> myQueue, BlockingQueue<Token> nextQueue,
             AtomicInteger globalPassCounter, int maxPasses, AtomicBoolean shutdownRequested) {
            this.id = id;
            this.myQueue = myQueue;
            this.nextQueue = nextQueue;
            this.globalPassCounter = globalPassCounter;
            this.maxPasses = maxPasses;
            this.shutdownRequested = shutdownRequested;
        }

        @Override
        public void run() {
            try {
                while (!Thread.currentThread().isInterrupted() && !shutdownRequested.get()) {
                    // Wait for token
                    Token token = myQueue.take(); // blocks here until token arrives
                    token.increment();
                    int pass = token.getPassCount();
                    globalPassCounter.set(pass);
                    System.out.printf("[Pass %3d] Node-%d: received %s%n", pass, id, token);

                    // Decide to enter critical section (40% chance)
                    boolean enterCS = rnd.nextInt(100) < 40;
                    if (enterCS) {
                        enterCriticalSection(pass);
                        // simulate some work inside CS
                        try {
                            Thread.sleep(80 + rnd.nextInt(200));
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                        }
                        exitCriticalSection(pass);
                    } else {
                        System.out.printf("[Pass %3d] Node-%d: skipping CS.%n", pass, id);
                    }

                    // Check for termination condition
                    if (pass >= maxPasses) {
                        System.out.printf("[Pass %3d] Node-%d: reached max passes (%d). Passing once and requesting shutdown.%n",
                                pass, id, maxPasses);
                        // pass token so next node won't block
                        nextQueue.put(token);
                        // initiate graceful shutdown (single flag)
                        shutdownRequested.set(true);
                        break;
                    }

                    // Forward token to next node
                    nextQueue.put(token);
                }
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                System.out.printf("Node-%d: interrupted and exiting.%n", id);
            } catch (Exception ex) {
                System.err.printf("Node-%d: unexpected error: %s%n", id, ex.getMessage());
                ex.printStackTrace();
            } finally {
                // Optionally log exit
                System.out.printf("Node-%d: thread terminating.%n", id);
            }
        }

        private void enterCriticalSection(int pass) {
            System.out.printf("[Pass %3d] Node-%d >>> ENTERING CRITICAL SECTION <<<%n", pass, id);
        }

        private void exitCriticalSection(int pass) {
            System.out.printf("[Pass %3d] Node-%d <<< EXITING CRITICAL SECTION >>>%n", pass, id);
        }
    }

    // Main: create queues, nodes and start simulation
    public static void main(String[] args) throws Exception {
    	
        Scanner sc = new Scanner(System.in);
        System.out.println("Token Ring Mutual Exclusion (Single-JVM Eclipse-friendly)");

        System.out.print("Enter number of processes (N) [default 5]: ");
        String nStr = sc.nextLine().trim();
        int N = nStr.isEmpty() ? 5 : Integer.parseInt(nStr);

        System.out.print("Enter maximum token passes before termination [default 30]: ");
        String mStr = sc.nextLine().trim();
        int maxPasses = mStr.isEmpty() ? 30 : Integer.parseInt(mStr);

        System.out.printf("Starting simulation with %d processes, maxPasses=%d%n", N, maxPasses);

        @SuppressWarnings("unchecked")
        BlockingQueue<Token>[] queues = new LinkedBlockingQueue[N];
        for (int i = 0; i < N; i++) {
            queues[i] = new LinkedBlockingQueue<>(1); // capacity 1 ensures only one token
        }

        AtomicInteger globalPassCounter = new AtomicInteger(0);
        AtomicBoolean shutdownRequested = new AtomicBoolean(false);
        ExecutorService exec = Executors.newFixedThreadPool(N);

        // Create and start nodes
        for (int i = 0; i < N; i++) {
            BlockingQueue<Token> myQ = queues[i];
            BlockingQueue<Token> nextQ = queues[(i + 1) % N];

            Node node = new Node(i + 1, myQ, nextQ, globalPassCounter, maxPasses, shutdownRequested);
            exec.submit(node);
        }

        // Inject initial token into node 1
        Token initial = new Token(0);
        queues[0].put(initial);
        System.out.println("Initial token injected into Node-1.");

        // Monitor thread to observe shutdownRequested
        while (!shutdownRequested.get()) {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }

        // Graceful shutdown
        System.out.println("Shutdown requested — waiting for threads to finish...");
        exec.shutdown();
        if (!exec.awaitTermination(3, TimeUnit.SECONDS)) {
            System.out.println("Forcing shutdown of executor...");
            exec.shutdownNow();
        }

        System.out.println("Simulation finished. Total token passes = " + globalPassCounter.get());
        sc.close();
    }
}

