package prac4_1;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.Naming;

public class AddServiceImpl extends UnicastRemoteObject implements AddService {

    private static final long serialVersionUID = 1L;

    protected AddServiceImpl() throws RemoteException {
        super();
    }

    @Override
    public int add(int a, int b) throws RemoteException {
        return a + b;
    }

    public static void main(String[] args) {
        try {
            // Create service instance
            AddServiceImpl service = new AddServiceImpl();

            // Create registry programmatically (avoids running rmiregistry manually)
            Registry registry = LocateRegistry.createRegistry(1099);

            // Bind the service with a name
            String name = "AddService";
            Naming.rebind("rmi://localhost:1099/" + name, service);

            System.out.println("AddService bound and ready on rmi://localhost:1099/" + name);
        } 
        catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
