package prac4_1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.Naming;

public class AddClientGUI extends JFrame {

    private JTextField tfNum1;
    private JTextField tfNum2;
    private JButton btnAdd;
    private JLabel lblResult;

    private AddService addService;

    public AddClientGUI() {
        super("RMI Add Client");

        // Try to look up remote service
        try {
            String url = "rmi://localhost:1099/AddService";
            addService = (AddService) Naming.lookup(url);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                this,
                "Could not locate remote service:\n" + e.getMessage(),
                "RMI Lookup Error",
                JOptionPane.ERROR_MESSAGE
            );
            // Allow GUI to open for local testing, but disable the button
        }

        initUI();
    }

    private void initUI() {
        tfNum1 = new JTextField(10);
        tfNum2 = new JTextField(10);
        btnAdd = new JButton("Add");
        lblResult = new JLabel("Result: ");

        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        inputPanel.add(new JLabel("Number 1:"));
        inputPanel.add(tfNum1);
        inputPanel.add(new JLabel("Number 2:"));
        inputPanel.add(tfNum2);
        inputPanel.add(btnAdd);

        this.setLayout(new BorderLayout(10, 10));
        this.add(inputPanel, BorderLayout.CENTER);

        JPanel resultPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        resultPanel.add(lblResult);
        this.add(resultPanel, BorderLayout.SOUTH);

        btnAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doAdd();
            }
        });

        // If service wasn't found, disable the button
        if (addService == null) {
            btnAdd.setEnabled(false);
        }

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setLocationRelativeTo(null); // Center window
        this.setVisible(true);
    }

    private void doAdd() {
        try {
            int a = Integer.parseInt(tfNum1.getText().trim());
            int b = Integer.parseInt(tfNum2.getText().trim());

            // Remote call
            int res = addService.add(a, b);
            lblResult.setText("Result: " + res);
        } 
        catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(
                this,
                "Please enter valid integers.",
                "Input Error",
                JOptionPane.WARNING_MESSAGE
            );
        } 
        catch (Exception ex) {
            JOptionPane.showMessageDialog(
                this,
                "Remote error: " + ex.getMessage(),
                "RMI Error",
                JOptionPane.ERROR_MESSAGE
            );
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Run on Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> new AddClientGUI());
    }
}

