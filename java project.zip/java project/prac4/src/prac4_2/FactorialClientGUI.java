package prac4_2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.rmi.Naming;

public class FactorialClientGUI extends JFrame {

    private JTextField tfNumber;
    private JLabel lblResult;
    private FactorialService factorialService;

    public FactorialClientGUI() {
        super("RMI Factorial Calculator");
        try {
            factorialService = (FactorialService) Naming.lookup("rmi://localhost:1099/FactorialService");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Could not connect to RMI Server:\n" + e.getMessage());
        }
        initUI();
    }

    private void initUI() {
        tfNumber = new JTextField(10);
        JButton btnCalc = new JButton("Find Factorial");
        lblResult = new JLabel("Result: ");

        JPanel panel = new JPanel();
        panel.add(new JLabel("Enter Number:"));
        panel.add(tfNumber);
        panel.add(btnCalc);

        add(panel, BorderLayout.CENTER);
        add(lblResult, BorderLayout.SOUTH);

        btnCalc.addActionListener(e -> doFactorial());

        setSize(350, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void doFactorial() {
        try {
            int n = Integer.parseInt(tfNumber.getText().trim());
            long res = factorialService.factorial(n);
            lblResult.setText("Result: " + res);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FactorialClientGUI());
    }
}
