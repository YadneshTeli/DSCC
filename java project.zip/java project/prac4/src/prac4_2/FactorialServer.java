package prac4_2;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

public class FactorialServer extends UnicastRemoteObject implements FactorialService {

    protected FactorialServer() throws java.rmi.RemoteException {
        super();
    }

    public long factorial(int n) throws java.rmi.RemoteException {
        long fact = 1;
        for (int i = 1; i <= n; i++) fact *= i;
        System.out.println("Server received: " + n + ", returning factorial: " + fact);
        return fact;
    }

    public static void main(String[] args) {
        try {
            LocateRegistry.createRegistry(1099);
            FactorialServer service = new FactorialServer();
            Naming.rebind("rmi://localhost:1099/FactorialService", service);
            System.out.println("FactorialService ready at rmi://localhost:1099/FactorialService");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

