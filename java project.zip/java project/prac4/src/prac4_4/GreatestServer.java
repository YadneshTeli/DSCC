package prac4_4;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

public class GreatestServer extends UnicastRemoteObject implements GreatestService {

    protected GreatestServer() throws java.rmi.RemoteException {
        super();
    }

    @Override
    public int greatest(int a, int b) throws java.rmi.RemoteException {
        int result = (a > b) ? a : b;
        System.out.println("Server received: a=" + a + ", b=" + b + ", returning greatest: " + result);
        return result;
    }

    public static void main(String[] args) {
        try {
            LocateRegistry.createRegistry(1099);
            GreatestServer service = new GreatestServer();
            Naming.rebind("rmi://localhost:1099/GreatestService", service);
            System.out.println("GreatestService ready at rmi://localhost:1099/GreatestService");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
