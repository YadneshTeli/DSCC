package prac4_4;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface GreatestService extends Remote {
    int greatest(int a, int b) throws RemoteException;
}
