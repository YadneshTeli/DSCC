package prac4_4;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.rmi.Naming;

public class GreatestClientGUI extends JFrame {

    private JTextField tfNum1, tfNum2;
    private JLabel lblResult;
    private GreatestService greatestService;

    public GreatestClientGUI() {
        super("RMI Greatest of Two Numbers");
        try {
            greatestService = (GreatestService) Naming.lookup("rmi://localhost:1099/GreatestService");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Could not connect to RMI Server:\n" + e.getMessage());
        }
        initUI();
    }

    private void initUI() {
        tfNum1 = new JTextField(10);
        tfNum2 = new JTextField(10);
        JButton btnFind = new JButton("Find Greatest");
        lblResult = new JLabel("Result: ");

        JPanel panel = new JPanel();
        panel.add(new JLabel("Number 1:"));
        panel.add(tfNum1);
        panel.add(new JLabel("Number 2:"));
        panel.add(tfNum2);
        panel.add(btnFind);

        add(panel, BorderLayout.CENTER);
        add(lblResult, BorderLayout.SOUTH);

        btnFind.addActionListener(e -> doFind());

        setSize(400, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void doFind() {
        try {
            int a = Integer.parseInt(tfNum1.getText().trim());
            int b = Integer.parseInt(tfNum2.getText().trim());
            int res = greatestService.greatest(a, b);
            lblResult.setText("Result: Greatest is " + res);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GreatestClientGUI());
    }
}
