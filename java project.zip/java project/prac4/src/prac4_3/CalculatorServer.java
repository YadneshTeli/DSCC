package prac4_3;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

public class CalculatorServer extends UnicastRemoteObject implements CalculatorService {

    protected CalculatorServer() throws java.rmi.RemoteException {
        super();
    }

    @Override
    public double add(double a, double b) throws java.rmi.RemoteException {
        System.out.println("Server received: " + a + " + " + b);
        return a + b;
    }

    @Override
    public double subtract(double a, double b) throws java.rmi.RemoteException {
        System.out.println("Server received: " + a + " - " + b);
        return a - b;
    }

    @Override
    public double multiply(double a, double b) throws java.rmi.RemoteException {
        System.out.println("Server received: " + a + " * " + b);
        return a * b;
    }

    @Override
    public double divide(double a, double b) throws java.rmi.RemoteException {
        System.out.println("Server received: " + a + " / " + b);
        if (b == 0) throw new ArithmeticException("Division by zero");
        return a / b;
    }

    public static void main(String[] args) {
        try {
            // Create RMI registry programmatically
            LocateRegistry.createRegistry(1099);
            CalculatorServer service = new CalculatorServer();

            // Bind the service
            Naming.rebind("rmi://localhost:1099/CalculatorService", service);

            System.out.println("CalculatorService bound and ready on rmi://localhost:1099/CalculatorService");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

