package prac4_3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.rmi.Naming;

public class CalculatorClientGUI extends JFrame {

    private JTextField tfNum1, tfNum2;
    private JLabel lblResult;
    private CalculatorService calcService;

    public CalculatorClientGUI() {
        super("RMI Basic Calculator");

        try {
            // Connect to RMI service
            calcService = (CalculatorService) Naming.lookup("rmi://localhost:1099/CalculatorService");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error connecting to RMI Server:\n" + e.getMessage());
        }

        initUI();
    }

    private void initUI() {
        tfNum1 = new JTextField(10);
        tfNum2 = new JTextField(10);
        lblResult = new JLabel("Result: ");

        JButton btnAdd = new JButton("+");
        JButton btnSub = new JButton("-");
        JButton btnMul = new JButton("*");
        JButton btnDiv = new JButton("/");

        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Number 1:"));
        inputPanel.add(tfNum1);
        inputPanel.add(new JLabel("Number 2:"));
        inputPanel.add(tfNum2);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnSub);
        buttonPanel.add(btnMul);
        buttonPanel.add(btnDiv);

        JPanel resultPanel = new JPanel();
        resultPanel.add(lblResult);

        setLayout(new BorderLayout(10, 10));
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(resultPanel, BorderLayout.SOUTH);

        // Event handling for each operation
        btnAdd.addActionListener(e -> doOperation("ADD"));
        btnSub.addActionListener(e -> doOperation("SUB"));
        btnMul.addActionListener(e -> doOperation("MUL"));
        btnDiv.addActionListener(e -> doOperation("DIV"));

        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void doOperation(String op) {
        try {
            double a = Double.parseDouble(tfNum1.getText().trim());
            double b = Double.parseDouble(tfNum2.getText().trim());
            double result = 0;

            switch (op) {
                case "ADD":
                    result = calcService.add(a, b);
                    break;
                case "SUB":
                    result = calcService.subtract(a, b);
                    break;
                case "MUL":
                    result = calcService.multiply(a, b);
                    break;
                case "DIV":
                    result = calcService.divide(a, b);
                    break;
            }

            lblResult.setText("Result: " + result);

        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Enter valid numbers!");
        } catch (ArithmeticException ae) {
            JOptionPane.showMessageDialog(this, "Error: " + ae.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "RMI Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CalculatorClientGUI());
    }
}

