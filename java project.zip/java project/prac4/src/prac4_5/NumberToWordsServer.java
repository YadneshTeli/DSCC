package prac4_5;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

public class NumberToWordsServer extends UnicastRemoteObject implements NumberToWordsService {

    protected NumberToWordsServer() throws java.rmi.RemoteException {
        super();
    }

    private static final String[] units = {
        "", "One", "Two", "Three", "Four", "Five", "Six",
        "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve",
        "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen",
        "Eighteen", "Nineteen"
    };
    private static final String[] tens = {
        "", "", "Twenty", "Thirty", "Forty", "Fifty",
        "Sixty", "Seventy", "Eighty", "Ninety"
    };

    @Override
    public String convert(int n) throws java.rmi.RemoteException {
        System.out.println("Server received number: " + n);
        if (n == 0) return "Zero";
        if (n < 0) return "Minus " + convert(-n);
        return numToWords(n).trim();
    }

    private String numToWords(int n) {
        if (n < 20) return units[n];
        if (n < 100) return tens[n / 10] + " " + units[n % 10];
        if (n < 1000) return units[n / 100] + " Hundred " + numToWords(n % 100);
        if (n < 1000000) return numToWords(n / 1000) + " Thousand " + numToWords(n % 1000);
        return "Number too large";
    }

    public static void main(String[] args) {
        try {
            LocateRegistry.createRegistry(1099);
            NumberToWordsServer service = new NumberToWordsServer();
            Naming.rebind("rmi://localhost:1099/NumberToWordsService", service);
            System.out.println("NumberToWordsService ready at rmi://localhost:1099/NumberToWordsService");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
