package prac4_5;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface NumberToWordsService extends Remote {
    String convert(int n) throws RemoteException;
}
