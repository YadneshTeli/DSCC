package prac4_5;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.rmi.Naming;

public class NumberToWordsClientGUI extends JFrame {

    private JTextField tfNumber;
    private JLabel lblResult;
    private NumberToWordsService wordsService;

    public NumberToWordsClientGUI() {
        super("RMI Number to Words Converter");
        try {
            wordsService = (NumberToWordsService) Naming.lookup("rmi://localhost:1099/NumberToWordsService");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Could not connect to RMI Server:\n" + e.getMessage());
        }
        initUI();
    }

    private void initUI() {
        tfNumber = new JTextField(10);
        JButton btnConvert = new JButton("Convert to Words");
        lblResult = new JLabel("Result: ");

        JPanel panel = new JPanel();
        panel.add(new JLabel("Enter Number:"));
        panel.add(tfNumber);
        panel.add(btnConvert);

        add(panel, BorderLayout.CENTER);
        add(lblResult, BorderLayout.SOUTH);

        btnConvert.addActionListener(e -> doConvert());

        setSize(400, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void doConvert() {
        try {
            int n = Integer.parseInt(tfNumber.getText().trim());
            String res = wordsService.convert(n);
            lblResult.setText("Result: " + res);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new NumberToWordsClientGUI());
    }
}
