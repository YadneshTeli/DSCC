/**
 * 
 */
/**
 * 
 */
module prac4 {
	requires java.rmi;
	requires java.desktop;
	opens prac4_1 to java.rmi;
	opens prac4_2 to java.rmi;
	opens prac4_3 to java.rmi;
	opens prac4_4 to java.rmi;
	opens prac4_5 to java.rmi;
}